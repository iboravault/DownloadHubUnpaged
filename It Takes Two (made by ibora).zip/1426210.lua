-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1426210)
addappid(1426211,0,"c450c44e032e27d0308cf864259fb2af91bcfc58401a0caf33bb8efba85bb323")
addappid(1426390)
